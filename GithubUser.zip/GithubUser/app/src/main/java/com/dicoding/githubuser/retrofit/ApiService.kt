package com.dicoding.githubuser.retrofit

import com.dicoding.githubuser.response.DetailUserResponse
import com.dicoding.githubuser.response.FollowerResponseItem
import com.dicoding.githubuser.response.FollowingResponseItem
import com.dicoding.githubuser.response.GithubResponse
import com.dicoding.githubuser.response.ItemsItem
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {

    @GET("search/users")
    fun getListUser(
        @Query("q") query: String
    ): Call<GithubResponse>

    @GET("users/{username}")
    fun getUserDetails(
        @Path("username") username: String?
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    fun getUserFollowers(
        @Path("username") username: String?
    ): Call<List<ItemsItem>>

    @GET("users/{username}/following")
    fun getUserFollowings(
        @Path("username") username: String?
    ): Call<List<ItemsItem>>
}