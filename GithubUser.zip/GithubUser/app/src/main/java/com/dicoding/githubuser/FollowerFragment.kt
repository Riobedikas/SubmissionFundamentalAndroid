package com.dicoding.githubuser

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuser.adapter.UserListAdapter
import com.dicoding.githubuser.databinding.FragmentFollowerBinding
import com.dicoding.githubuser.model.DetailViewModel
import com.dicoding.githubuser.response.ItemsItem


class FollowerFragment : Fragment() {

    private lateinit var binding: FragmentFollowerBinding
    private val detailViewModel by viewModels<DetailViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowerBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val layoutManager = LinearLayoutManager(context)
        binding.rvFollowers.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(context, layoutManager.orientation)
        binding.rvFollowers.addItemDecoration(itemDecoration)

        arguments?.let {
            val positions = it.getInt(ARG_POSITIONS)
            val username = it.getString(ARG_USERNAME)

            if (positions == 1) {
                detailViewModel.getUserFollowers("$username")
                detailViewModel.getFollower.observe(viewLifecycleOwner) { follower ->
                    setDataUser(follower)
                }
            } else {
                detailViewModel.getUserFollowings("$username")
                detailViewModel.getFollowing.observe(viewLifecycleOwner) { following ->
                    setDataUser(following)
                }
            }
            detailViewModel.isLoadingDetail.observe(viewLifecycleOwner) {
                showLoading(it)
            }
        }
    }

    private fun showLoading(state: Boolean) {
        binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE
    }

    private fun setDataUser(data: List<ItemsItem>) {
        val adapter = UserListAdapter()
        adapter.submitList(data)
        binding.rvFollowers.adapter = adapter
    }

    companion object {
        const val ARG_SECTION_NUMBER = "section_number"
        const val ARG_USERNAME = "username"
        const val ARG_POSITIONS = "positions"
    }
}