package com.dicoding.githubuser.model

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuser.response.DetailUserResponse
import com.dicoding.githubuser.response.ItemsItem
import com.dicoding.githubuser.retrofit.ApiConfig
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DetailViewModel : ViewModel() {

    companion object {
        private const val TAG = "DetailViewModel"
    }

    private val _detailUser = MutableLiveData<DetailUserResponse>()
    val detailUser: LiveData<DetailUserResponse> = _detailUser

    private val _isLoadingDetail = MutableLiveData<Boolean>()
    val isLoadingDetail: LiveData<Boolean> = _isLoadingDetail
    val username: MutableLiveData<String> = MutableLiveData()

    private val _follower = MutableLiveData<List<ItemsItem>>()
    val getFollower: LiveData<List<ItemsItem>> = _follower

    private val _following = MutableLiveData<List<ItemsItem>>()
    val getFollowing: LiveData<List<ItemsItem>> = _following

    fun getUser(input: String) {
        _isLoadingDetail.value = true
        val client = ApiConfig.getApiService().getUserDetails(input)
        client.enqueue(object : Callback<DetailUserResponse> {
            override fun onResponse(
                call: Call<DetailUserResponse>,
                response: Response<DetailUserResponse>
            ) {
                _isLoadingDetail.value = false
                if (response.isSuccessful) {
                    _detailUser.value = response.body()
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isLoadingDetail.value = false
                t.message?.let { Log.d("failure", it) }
            }

        })
    }

    fun getUserFollowers(input: String) {
        _isLoadingDetail.value = true
        val client = ApiConfig.getApiService().getUserFollowers(input)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                _isLoadingDetail.value = false
                if (response.isSuccessful) {
                    _follower.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoadingDetail.value = false
                t.message?.let { Log.d("failure", it) }
            }

        })
    }

    fun getUserFollowings(input: String) {
        _isLoadingDetail.value = true
        val client = ApiConfig.getApiService().getUserFollowings(input)
        client.enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) {
                _isLoadingDetail.value = false
                if (response.isSuccessful) {
                    _following.value = response.body()
                }
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                _isLoadingDetail.value = false
                t.message?.let { Log.d("failure", it) }
            }

        })
    }
}